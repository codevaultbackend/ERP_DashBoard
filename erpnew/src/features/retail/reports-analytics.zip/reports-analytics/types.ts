export type DashboardSummary = {
  totalCustomers: number;
  totalRevenue: number;
  totalSales: number;
  totalCashReceived: number;
  accountTransfer: number;
};

export type CashVsAccountItem = {
  date: string;
  day: string;
  cash: number;
  online: number;
  total: number;
};

export type CategorySalesItem = {
  category: string;
  revenue: number;
  percentage: number;
};

export type TypeDistributionItem = {
  label: string;
  value: number;
};

export type TopProductItem = {
  rank: number;
  product_name: string;
  category: string;
  units_sold: number;
  total_revenue: number;
  performance: number;
};

export type ReportsApiData = {
  dashboardSummary: DashboardSummary;
  cashVsAccount: CashVsAccountItem[];
  categorySales: CategorySalesItem[];
  typeDistribution: TypeDistributionItem[];
  topProducts: TopProductItem[];
};

export type ReportsApiResponse = {
  success: boolean;
  message: string;
  data: ReportsApiData;
};