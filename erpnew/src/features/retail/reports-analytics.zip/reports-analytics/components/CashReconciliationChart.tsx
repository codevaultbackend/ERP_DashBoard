"use client";

import React from "react";
import { IndianRupee } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import SectionCard from "./SectionCard";
import { formatCurrency, formatCurrencyCompact } from "../utils";
import { useResponsiveChart } from "../hooks/useResponsiveChart";

type Row = {
  day: string;
  date: string;
  cash: number;
  account: number;
  total: number;
};

function ReconciliationTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ payload: Row }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;

  const row = payload[0].payload;

  return (
    <div className="rounded-[16px] border border-[#E5E7EB] bg-white px-3 py-3 shadow-[0px_12px_30px_rgba(15,23,42,0.12)] sm:rounded-[18px] sm:px-4">
      <div className="space-y-1 text-[12px] leading-[1.35] text-[#4B5563] sm:text-[14px] lg:text-[15px]">
        <p className="font-medium text-[#111827]">{label}</p>
        <p>
          Cash Received: <span className="font-semibold">{formatCurrency(row.cash)}</span>
        </p>
        <p>
          Account Transfer: <span className="font-semibold">{formatCurrency(row.account)}</span>
        </p>
        <p>
          Total Sales: <span className="font-semibold">{formatCurrency(row.total)}</span>
        </p>
      </div>
    </div>
  );
}

type Props = {
  data: Row[];
};

export default function CashReconciliationChart({ data }: Props) {
  const { barSize } = useResponsiveChart();

  const maxValue = Math.max(1000, ...data.map((item) => item.total || 0));
  const yMax = Math.ceil(maxValue * 1.25);

  const ticks = [
    0,
    Math.round(yMax * 0.25),
    Math.round(yMax * 0.5),
    Math.round(yMax * 0.75),
    yMax,
  ];

  return (
    <SectionCard
      title="Cash vs Account Reconciliation"
      subtitle="Daily reconciliation of cash and account transfers with total sales"
      icon={<IndianRupee className="h-5 w-5 text-[#059669] sm:h-6 sm:w-6" strokeWidth={2.3} />}
      headerClassName="bg-[#E8F5F0]"
      action={
        <button className="inline-flex h-[34px] items-center gap-2 rounded-[10px] border border-[#E5E7EB] bg-white px-3 text-[12px] font-medium text-[#4B5563] shadow-[0px_1px_2px_rgba(15,23,42,0.03)] sm:h-[36px] sm:rounded-[11px] sm:px-3.5 sm:text-[13px] lg:h-[38px] lg:rounded-[12px] lg:px-4 lg:text-[14px]">
          Daily
          <svg
            width="14"
            height="14"
            viewBox="0 0 20 20"
            fill="none"
            className="opacity-70"
          >
            <path
              d="M5 7.5L10 12.5L15 7.5"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      }
      bodyClassName="px-2 pb-3 pt-3 sm:px-4 sm:pb-4 sm:pt-4 lg:px-5 lg:pb-5 lg:pt-5"
    >
      <div className="h-[260px] w-full rounded-[18px] bg-[#FCFDFD] px-1.5 pt-2 sm:h-[320px] sm:rounded-[22px] sm:px-3 sm:pt-3 lg:h-[380px] lg:rounded-[24px] lg:px-4">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 16, right: 6, left: -12, bottom: 8 }}
            barSize={barSize}
          >
            <CartesianGrid vertical={false} stroke="#E5E7EB" strokeDasharray="3 4" />
            <XAxis
              dataKey="day"
              tickLine={false}
              axisLine={false}
              interval={0}
              tick={{ fill: "#9CA3AF", fontSize: 11 }}
            />
            <YAxis
              tickFormatter={formatCurrencyCompact}
              tickLine={false}
              axisLine={false}
              tick={{ fill: "#9CA3AF", fontSize: 11 }}
              domain={[0, yMax]}
              ticks={ticks}
              width={50}
            />
            <Tooltip
              cursor={{ fill: "rgba(17, 24, 39, 0.03)" }}
              content={<ReconciliationTooltip />}
            />
            <Bar dataKey="total" radius={[8, 8, 0, 0]} fill="#3B93E8" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </SectionCard>
  );
}