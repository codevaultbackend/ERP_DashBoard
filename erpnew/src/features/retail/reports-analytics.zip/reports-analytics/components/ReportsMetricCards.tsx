"use client";

import React from "react";
import {
  BadgeIndianRupee,
  ReceiptText,
  Wallet2,
  Landmark,
  Users,
} from "lucide-react";
import MetricCard from "./MetricCard";
import { formatCurrency, formatNumber } from "../utils";
import type { DashboardSummary } from "../types";

type Props = {
  summary?: DashboardSummary | null;
};

const defaultSummary: DashboardSummary = {
  totalCustomers: 0,
  totalRevenue: 0,
  totalSales: 0,
  totalCashReceived: 0,
  accountTransfer: 0,
};

export default function ReportsMetricCards({ summary }: Props) {
  const safeSummary = {
    totalCustomers: Number(summary?.totalCustomers ?? defaultSummary.totalCustomers),
    totalRevenue: Number(summary?.totalRevenue ?? defaultSummary.totalRevenue),
    totalSales: Number(summary?.totalSales ?? defaultSummary.totalSales),
    totalCashReceived: Number(
      summary?.totalCashReceived ?? defaultSummary.totalCashReceived
    ),
    accountTransfer: Number(
      summary?.accountTransfer ?? defaultSummary.accountTransfer
    ),
  };

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
      <MetricCard
        title="Total Customers"
        value={formatNumber(safeSummary.totalCustomers)}
        icon={<Users className="h-5 w-5 text-[#2563EB]" strokeWidth={2.2} />}
        iconWrapClassName="bg-[#DBEAFE]"
      />

      <MetricCard
        title="Total Revenue"
        value={formatCurrency(safeSummary.totalRevenue)}
        icon={
          <BadgeIndianRupee
            className="h-5 w-5 text-[#16A34A]"
            strokeWidth={2.2}
          />
        }
        iconWrapClassName="bg-[#DCFCE7]"
      />

      <MetricCard
        title="Total Sales"
        value={formatCurrency(safeSummary.totalSales)}
        icon={
          <ReceiptText className="h-5 w-5 text-[#9333EA]" strokeWidth={2.2} />
        }
        iconWrapClassName="bg-[#F3E8FF]"
      />

      <MetricCard
        title="Total Cash Received"
        value={formatCurrency(safeSummary.totalCashReceived)}
        icon={<Wallet2 className="h-5 w-5 text-[#16A34A]" strokeWidth={2.2} />}
        iconWrapClassName="bg-[#DCFCE7]"
      />

      <MetricCard
        title="Account Transfer"
        value={formatCurrency(safeSummary.accountTransfer)}
        icon={<Landmark className="h-5 w-5 text-[#3B82F6]" strokeWidth={2.2} />}
        iconWrapClassName="bg-[#DBEAFE]"
      />
    </div>
  );
}