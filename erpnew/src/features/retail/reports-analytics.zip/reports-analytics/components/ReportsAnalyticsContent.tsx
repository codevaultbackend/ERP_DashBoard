"use client";

import React from "react";
import CashReconciliationChart from "./CashReconciliationChart";
import CategorySalesChart from "./CategorySalesChart";
import MetalTypeChart from "./MetalTypeChart";
import TopProductsTable from "./TopProductsTable";
import ReportsMetricCards from "./ReportsMetricCards";
import { useReportsAnalytics } from "../hooks/useReportsAnalytics";

export default function ReportsAnalyticsContent() {
  const {
    dashboardSummary,
    cashVsAccountData,
    categorySalesData,
    typeDistributionData,
    topProductsData,
    loading,
    error,
    refetch,
  } = useReportsAnalytics();

  if (loading) {
    return (
      <div className="space-y-4 p-4 sm:p-5 lg:p-6">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-[102px] animate-pulse rounded-[22px] border border-[#E5E7EB] bg-white sm:rounded-[24px] lg:rounded-[28px]"
            />
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="h-[420px] animate-pulse rounded-[22px] border border-[#E5E7EB] bg-white sm:rounded-[26px] lg:rounded-[30px]" />
          <div className="h-[420px] animate-pulse rounded-[22px] border border-[#E5E7EB] bg-white sm:rounded-[26px] lg:rounded-[30px]" />
        </div>

        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="h-[420px] animate-pulse rounded-[22px] border border-[#E5E7EB] bg-white sm:rounded-[26px] lg:rounded-[30px]" />
          <div className="h-[420px] animate-pulse rounded-[22px] border border-[#E5E7EB] bg-white sm:rounded-[26px] lg:rounded-[30px]" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 sm:p-5 lg:p-6">
        <div className="rounded-[22px] border border-[#FECACA] bg-[#FEF2F2] px-4 py-4 text-[#991B1B] shadow-[0px_4px_18px_rgba(15,23,42,0.03)] sm:rounded-[24px] lg:rounded-[28px]">
          <p className="text-[15px] font-semibold">Failed to load reports</p>
          <p className="mt-1 text-[13px]">{error}</p>
          <button
            onClick={refetch}
            className="mt-4 inline-flex h-[38px] items-center justify-center rounded-[12px] bg-[#111827] px-4 text-[13px] font-medium text-white"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-4 sm:space-y-5 sm:p-5 lg:space-y-6 lg:p-6">
      <ReportsMetricCards summary={dashboardSummary} />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <CashReconciliationChart data={cashVsAccountData} />
        <CategorySalesChart data={categorySalesData} />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <MetalTypeChart data={typeDistributionData} />
        <TopProductsTable products={topProductsData} />
      </div>
    </div>
  );
}