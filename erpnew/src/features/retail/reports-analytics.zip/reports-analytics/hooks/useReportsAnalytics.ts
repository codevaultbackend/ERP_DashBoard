"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { fetchReportsAnalytics } from "../api";
import {
  mapCashVsAccount,
  mapCategorySales,
  mapTopProducts,
  mapTypeDistribution,
} from "../utils";
import type { ReportsApiData } from "../types";

export function useReportsAnalytics() {
  const [data, setData] = useState<ReportsApiData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const res = await fetchReportsAnalytics();
      setData(res);
    } catch (error) {
      setError(error instanceof Error ? error.message : "Failed to load reports");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const summary = data?.dashboardSummary ?? {
    totalCustomers: 0,
    totalRevenue: 0,
    totalSales: 0,
    totalCashReceived: 0,
    accountTransfer: 0,
  };

  const cashVsAccountData = useMemo(() => mapCashVsAccount(data?.cashVsAccount ?? []), [data]);
  const categorySalesData = useMemo(() => mapCategorySales(data?.categorySales ?? []), [data]);
  const typeDistributionData = useMemo(
    () => mapTypeDistribution(data?.typeDistribution ?? []),
    [data]
  );
  const topProductsData = useMemo(() => mapTopProducts(data?.topProducts ?? []), [data]);

  return {
    summary,
    cashVsAccountData,
    categorySalesData,
    typeDistributionData,
    topProductsData,
    loading,
    error,
    refetch: loadData,
  };
}