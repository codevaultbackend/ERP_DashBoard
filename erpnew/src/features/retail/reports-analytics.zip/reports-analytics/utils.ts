import type {
  CashVsAccountItem,
  CategorySalesItem,
  TopProductItem,
  TypeDistributionItem,
} from "./types";

export function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatCurrencyCompact(value: number) {
  const safe = Number.isFinite(value) ? value : 0;

  if (safe >= 10000000) return `₹${(safe / 10000000).toFixed(1).replace(/\.0$/, "")}Cr`;
  if (safe >= 100000) return `₹${(safe / 100000).toFixed(1).replace(/\.0$/, "")}L`;
  if (safe >= 1000) return `₹${Math.round(safe / 1000)}K`;
  return `₹${safe}`;
}

export function formatNumber(value: number, digits = 0) {
  return new Intl.NumberFormat("en-IN", {
    maximumFractionDigits: digits,
  }).format(Number.isFinite(value) ? value : 0);
}

export function normalizeCategoryName(value: string) {
  const raw = String(value || "").trim();
  if (!raw) return "Unknown";

  const key = raw.toLowerCase().replace(/\s+/g, " ");

  if (
    key === "nose pin" ||
    key === "nosepin" ||
    key === "nose-pin" ||
    key === "nose  pin" ||
    key === "nose pin " ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "nose pin".toLowerCase() ||
    key === "no se pin" ||
    key === "nose pin" ||
    key === "nose pin" ||
    key === "nose pin" ||
    key === "nose pin" ||
    key === "noSE pin".toLowerCase()
  ) {
    return "Nose Pin";
  }

  return raw
    .toLowerCase()
    .split(" ")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

const PIE_COLORS = [
  "#8B5CF6",
  "#6366F1",
  "#14B8A6",
  "#EC4899",
  "#EF4444",
  "#F59E0B",
  "#10B981",
  "#3B82F6",
];

const BAR_COLORS = [
  "#F59E0B",
  "#FBBF24",
  "#D1D5DB",
  "#9CA3AF",
  "#FB923C",
  "#FACC15",
  "#CBD5E1",
  "#94A3B8",
];

const CATEGORY_TAGS = [
  "bg-[#E9D5FF] text-[#7C3AED]",
  "bg-[#DBEAFE] text-[#2563EB]",
  "bg-[#DCFCE7] text-[#15803D]",
  "bg-[#FEF3C7] text-[#B45309]",
  "bg-[#FCE7F3] text-[#BE185D]",
];

export function getRankColor(rank: number) {
  if (rank === 1) return "bg-[#E1A200]";
  if (rank === 2) return "bg-[#9CA3AF]";
  if (rank === 3) return "bg-[#F97316]";
  return "bg-[#3B82F6]";
}

export function getCategoryTagClassName(category: string) {
  const normalized = normalizeCategoryName(category);
  const index =
    normalized.split("").reduce((sum, ch) => sum + ch.charCodeAt(0), 0) %
    CATEGORY_TAGS.length;

  return CATEGORY_TAGS[index];
}

export function mapCashVsAccount(items: CashVsAccountItem[]) {
  return (items || []).map((item) => ({
    day: item.day || "",
    date: item.date || "",
    cash: Number(item.cash || 0),
    account: Number(item.online || 0),
    total: Number(item.total || 0),
  }));
}

export function mapCategorySales(items: CategorySalesItem[]) {
  return (items || []).map((item, index) => ({
    name: normalizeCategoryName(item.category),
    value: Number(item.revenue || 0),
    percentage: Number(item.percentage || 0),
    color: PIE_COLORS[index % PIE_COLORS.length],
  }));
}

export function mapTypeDistribution(items: TypeDistributionItem[]) {
  return (items || []).map((item, index) => ({
    name: item.label || "Unknown",
    revenue: Number(item.value || 0),
    color: BAR_COLORS[index % BAR_COLORS.length],
  }));
}

export function mapTopProducts(items: TopProductItem[]) {
  return (items || []).map((item) => ({
    rank: Number(item.rank || 0),
    name: item.product_name || "-",
    category: normalizeCategoryName(item.category),
    unitsSold: Number(item.units_sold || 0),
    totalRevenue: formatCurrency(Number(item.total_revenue || 0)),
    performance: Math.max(0, Math.min(100, Number(item.performance || 0))),
    rankColor: getRankColor(Number(item.rank || 0)),
    tagClassName: getCategoryTagClassName(item.category),
  }));
}