import type { ReportsApiResponse } from "./types";

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_URL ||
  "https://erp-backend-1fey.onrender.com";

function getAuthToken() {
  if (typeof window === "undefined") return "";

  return (
    localStorage.getItem("token") ||
    document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      ?.split("=")[1] ||
    ""
  );
}

export async function fetchReportsAnalytics(): Promise<ReportsApiResponse["data"]> {
  const token = getAuthToken();

  const res = await fetch(`${API_BASE}/dash/report`, {
    method: "GET",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  const json = await res.json().catch(() => null);

  if (!res.ok) {
    throw new Error(json?.message || "Failed to fetch reports analytics");
  }

  if (!json?.success || !json?.data) {
    throw new Error(json?.message || "Invalid reports analytics response");
  }

  return json.data;
}